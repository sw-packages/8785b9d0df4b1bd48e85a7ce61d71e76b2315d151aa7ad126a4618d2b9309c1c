// SPDX-License-Identifier: MPL-2.0
// Copyright (C) 2016-2020 Egor Pugin <egor.pugin@gmail.com>

#include "package_id.h"

//#include <primitives/log.h>
//DECLARE_STATIC_LOGGER(logger, "package_id");

namespace sw
{

}
