// SPDX-License-Identifier: MPL-2.0
// Copyright (C) 2020 Egor Pugin <egor.pugin@gmail.com>

#pragma once

namespace sw
{

struct SW_SUPPORT_API SecurityContext
{
    // TODO:
    bool check() { return true; }
};

} // namespace sw
